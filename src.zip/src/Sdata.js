const sData = [
    {
        imgsrc:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQHjE4eApjpFWlpAdiC_aFG2FkfvimiGW0TK4mB-hc_T4Uitj9J",
        rating:"7.5",
        title:"THe Matrix",
        genre:"Action",
    },
    {
        imgsrc:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQHjE4eApjpFWlpAdiC_aFG2FkfvimiGW0TK4mB-hc_T4Uitj9J",
        rating:"7.5",
        title:"THe Matrix",
        genre:"Action",
    },
    {
        imgsrc:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQHjE4eApjpFWlpAdiC_aFG2FkfvimiGW0TK4mB-hc_T4Uitj9J",
        rating:"7.5",
        title:"THe Matrix",
        genre:"Action",
    },
    {
        imgsrc:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQHjE4eApjpFWlpAdiC_aFG2FkfvimiGW0TK4mB-hc_T4Uitj9J",
        rating:"7.5",
        title:"THe Matrix",
        genre:"Action",
    },
    {
        imgsrc:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQHjE4eApjpFWlpAdiC_aFG2FkfvimiGW0TK4mB-hc_T4Uitj9J",
        rating:"7.5",
        title:"THe Matrix",
        genre:"Action",
    },
]